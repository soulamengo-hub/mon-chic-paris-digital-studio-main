# MON CHIC PARIS Digital Studio 6.5.4

## Artikelübersicht

- Artikel können jetzt direkt in der Übersicht gelöscht werden.
- Vor dem Löschen erscheint eine deutliche Sicherheitsabfrage.
- Während des Löschens wird der Button gesperrt und der Status angezeigt.
- Nach erfolgreichem Löschen verschwindet der Artikel sofort aus der Liste.
- Zugehörige Produktbilder werden weiterhin über den vorhandenen API-Endpunkt aus Supabase Storage entfernt.

## Produktfotos

- Kartenbilder verwenden jetzt `object-fit: contain` statt `cover`.
- Das vollständige Kleidungsstück bleibt dadurch sichtbar und wird nicht mehr stark angeschnitten.
- Die Bildfläche wurde auf dem Desktop kompakter gestaltet.
- Ein neutraler Hintergrund sorgt bei unterschiedlichen Bildformaten für eine ruhige Ansicht.

## Technik

- Version und Health-Endpunkt auf 6.5.4 aktualisiert.
- Löschfunktion nutzt den vorhandenen Endpunkt `DELETE /api/products/[id]`.
