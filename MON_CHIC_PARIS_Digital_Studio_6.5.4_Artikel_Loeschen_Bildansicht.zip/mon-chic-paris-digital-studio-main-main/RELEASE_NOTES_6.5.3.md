# MON CHIC PARIS Digital Studio 6.5.3

## Fashion Intelligence

- Mehrbildanalyse für bis zu sieben Fotos eines Artikels
- Etikettenpriorität für Marke, Originalgröße und Materialzusammensetzung
- Schutz vor der falschen Produktmarke `MON CHIC` / `MON CHIC PARIS`
- Erweiterte Markenwissensbasis inklusive H&M, Zara, Mango, COS, Uniqlo und weiteren Marken
- Feldbezogene KI-Konfidenzen zwischen 0 und 100 Prozent
- Unsichere Marken-, Größen- und Materialwerte werden verworfen
- Anlass-Tags werden nur bei hoher Konfidenz übernommen
- Saison-, Größen- und Maßangaben werden aus der Analyse übernommen
- Automatische SKU-Erzeugung nach einer gültigen KI-Unterkategorie
- Strukturierte JSON-Ausgabe über die OpenAI Responses API

## Deployment

1. Änderungen auf den Branch `main` pushen.
2. Vercel-Deployment abwarten.
3. `/api/health` prüfen: Version `6.5.3`.
4. Einen Artikel mit Gesamtansicht sowie Marken-, Größen- und Materialetikett testen.

## Hinweise

KI-Angaben bleiben Vorschläge und müssen vor dem Speichern menschlich geprüft werden. Es erfolgt keine Echtheits- oder Preisbestätigung.
