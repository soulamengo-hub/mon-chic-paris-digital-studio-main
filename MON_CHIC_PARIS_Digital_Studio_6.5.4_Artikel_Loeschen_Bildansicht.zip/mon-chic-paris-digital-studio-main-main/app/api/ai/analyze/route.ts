import { NextResponse } from 'next/server';
import { categories, designerSuggestions, forbiddenBrands, type CategoryName } from '@/lib/catalog';

export const runtime = 'nodejs';

type ConfidenceMap = Record<string, number>;
type AnalysisResult = {
  brand?: string; category?: string; subcategory?: string; season?: string;
  original_size?: string; size_system?: string; de_size?: string; international_size?: string;
  color?: string; secondary_color?: string; material?: string; pattern?: string; condition?: string;
  era?: string; style_key?: string; occasions?: string[]; measurements?: string; notes?: string;
  confidence?: ConfidenceMap;
};

const allowedOccasions = ['Business','Casual','Chic','Abendgarderobe','Cocktail','Hochzeit','Dinner','Urlaub','Strand','Skiurlaub','Sportiv','Outdoor','Trauerfeier','Religiöse Feier','Weihnachten','Silvester'];
const allowedSeasons = ['Ganzjährig','Frühling','Sommer','Herbst','Winter'];
const allowedConditions = ['Neu mit Etikett','Neuwertig','Sehr gut','Gut','Akzeptabel'];
const allowedSizeSystems = ['DE','FR','IT','UK','US','One Size'];

function extractText(payload: any): string {
  if (typeof payload?.output_text === 'string') return payload.output_text;
  for (const item of payload?.output || []) for (const content of item?.content || []) if (typeof content?.text === 'string') return content.text;
  return '';
}
function clampConfidence(value: unknown) { const n = Number(value); return Number.isFinite(n) ? Math.max(0, Math.min(1, n)) : 0; }
function cleanText(value: unknown, max = 160) { return typeof value === 'string' ? value.trim().slice(0, max) : undefined; }
function canonicalBrand(value: unknown) {
  const raw = cleanText(value, 80); if (!raw) return undefined;
  if (forbiddenBrands.some(item => item.toLocaleLowerCase('de') === raw.toLocaleLowerCase('de'))) return undefined;
  return designerSuggestions.find(item => item.toLocaleLowerCase('de') === raw.toLocaleLowerCase('de')) || raw;
}
function validSubcategory(category: string | undefined, subcategory: unknown) {
  const value = cleanText(subcategory, 60); if (!category || !value || !(category in categories)) return undefined;
  return categories[category as CategoryName].find(item => item.toLocaleLowerCase('de') === value.toLocaleLowerCase('de'));
}
function parseJson(text: string): AnalysisResult {
  const cleaned = text.trim().replace(/^```json\s*/i, '').replace(/```$/i, '').trim();
  const start = cleaned.indexOf('{'); const end = cleaned.lastIndexOf('}');
  if (start < 0 || end < start) throw new Error('Die KI-Antwort enthielt kein gültiges JSON.');
  const raw = JSON.parse(cleaned.slice(start, end + 1)) as AnalysisResult;
  const confidence = Object.fromEntries(Object.entries(raw.confidence || {}).map(([k,v]) => [k, clampConfidence(v)]));
  const category = Object.keys(categories).find(item => item.toLocaleLowerCase('de') === cleanText(raw.category)?.toLocaleLowerCase('de'));
  const result: AnalysisResult = {
    brand: canonicalBrand(raw.brand), category, subcategory: validSubcategory(category, raw.subcategory),
    season: allowedSeasons.includes(String(raw.season)) ? String(raw.season) : undefined,
    original_size: cleanText(raw.original_size, 40), size_system: allowedSizeSystems.includes(String(raw.size_system)) ? String(raw.size_system) : undefined,
    de_size: cleanText(raw.de_size, 40), international_size: cleanText(raw.international_size, 40), color: cleanText(raw.color, 60),
    secondary_color: cleanText(raw.secondary_color, 60), material: cleanText(raw.material, 240), pattern: cleanText(raw.pattern, 80),
    condition: allowedConditions.includes(String(raw.condition)) ? String(raw.condition) : undefined, era: cleanText(raw.era, 60),
    style_key: cleanText(raw.style_key, 100), measurements: cleanText(raw.measurements, 500), notes: cleanText(raw.notes, 500), confidence,
  };
  result.occasions = Array.isArray(raw.occasions) ? raw.occasions.filter(v => allowedOccasions.includes(v) && clampConfidence(confidence[`occasion:${v}`] ?? confidence.occasions) >= .82) : [];
  for (const key of ['brand','original_size','material'] as const) if (result[key] && clampConfidence(confidence[key]) < .65) delete result[key];
  return result;
}

export async function POST(request: Request) {
  try {
    const apiKey = process.env.OPENAI_API_KEY;
    if (!apiKey) return NextResponse.json({ error: 'OPENAI_API_KEY ist in Vercel noch nicht eingerichtet.' }, { status: 503 });
    const body = await request.json() as { imageDataUrls?: string[]; imageDataUrl?: string };
    const imageDataUrls = (Array.isArray(body.imageDataUrls) ? body.imageDataUrls : body.imageDataUrl ? [body.imageDataUrl] : []).slice(0, 7);
    if (!imageDataUrls.length || imageDataUrls.some(url => !url.startsWith('data:image/'))) return NextResponse.json({ error: 'Für die Analyse wird mindestens ein Bild benötigt.' }, { status: 400 });
    if (imageDataUrls.some(url => url.length > 3_500_000) || imageDataUrls.reduce((sum, url) => sum + url.length, 0) > 14_000_000) return NextResponse.json({ error: 'Die Analysebilder sind insgesamt zu groß.' }, { status: 413 });

    const model = process.env.OPENAI_MODEL || 'gpt-4.1-mini';
    const prompt = `Du bist ein vorsichtiger Fashion-Intelligence-Assistent für Second-Hand-Mode. Analysiere ALLE Bilder als einen Artikel. Priorität: 1) Markenetikett/Logo, 2) Größenetikett, 3) Material-/Pflegeetikett, 4) Gesamtansicht, 5) Maßbandbilder. Etikettentext hat Vorrang vor visueller Vermutung. Erfinde niemals Marke, Größe, Material, Echtheit oder Preis. MON CHIC und MON CHIC PARIS sind Shopnamen und dürfen NIE als Produktmarke ausgegeben werden. Bei Unsicherheit leere Strings/Arrays und niedrige Konfidenz verwenden. category nur: ${Object.keys(categories).join(', ')}. subcategory passend aus: ${Object.entries(categories).map(([k,v])=>`${k}: ${v.join(', ')}`).join(' | ')}. occasions nur: ${allowedOccasions.join(', ')} und nur bei klarer visueller Begründung. confidence enthält Werte 0 bis 1 je ausgegebenem Feld; Anlass-Konfidenzen als "occasion:<Name>". Materialetikett möglichst originalgetreu, z. B. "97 % Baumwolle, 3 % Elasthan". measurements nur bei sichtbarem Maßband und ablesbaren Werten. Keine Echtheitsbestätigung.`;
    const response = await fetch('https://api.openai.com/v1/responses', {
      method: 'POST', headers: { Authorization: `Bearer ${apiKey}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ model, input: [{ role: 'user', content: [{ type: 'input_text', text: prompt }, ...imageDataUrls.map((image_url, index) => ({ type: 'input_image', image_url, detail: index === 0 ? 'high' : 'low' }))] }], text: { format: { type: 'json_schema', name: 'fashion_article_analysis', strict: true, schema: { type: 'object', additionalProperties: false, properties: {
        brand:{type:'string'}, category:{type:'string'}, subcategory:{type:'string'}, season:{type:'string'}, original_size:{type:'string'}, size_system:{type:'string'}, de_size:{type:'string'}, international_size:{type:'string'}, color:{type:'string'}, secondary_color:{type:'string'}, material:{type:'string'}, pattern:{type:'string'}, condition:{type:'string'}, era:{type:'string'}, style_key:{type:'string'}, occasions:{type:'array',items:{type:'string'}}, measurements:{type:'string'}, notes:{type:'string'}, confidence:{type:'object',additionalProperties:{type:'number'}}
      }, required:['brand','category','subcategory','season','original_size','size_system','de_size','international_size','color','secondary_color','material','pattern','condition','era','style_key','occasions','measurements','notes','confidence'] } } } }),
    });
    const payload = await response.json();
    if (!response.ok) return NextResponse.json({ error: payload?.error?.message || 'OpenAI-Analyse fehlgeschlagen.' }, { status: response.status });
    const text = extractText(payload); if (!text) return NextResponse.json({ error: 'Die KI hat keine auswertbare Antwort geliefert.' }, { status: 502 });
    return NextResponse.json({ ...parseJson(text), image_count: imageDataUrls.length });
  } catch (error) { return NextResponse.json({ error: error instanceof Error ? error.message : 'KI-Analyse fehlgeschlagen.' }, { status: 500 }); }
}
