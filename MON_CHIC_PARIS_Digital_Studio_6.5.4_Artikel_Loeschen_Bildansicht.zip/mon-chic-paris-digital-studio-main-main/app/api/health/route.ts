import { NextResponse } from 'next/server';

export async function GET() {
  return NextResponse.json({
    ok: true,
    service: 'MON CHIC PARIS · Digital Studio',
    version: '6.5.4',
  });
}
